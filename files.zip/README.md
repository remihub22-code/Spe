# Speed Skating Manager 2026

Jeu de management roller vitesse — Piste, Route & Marathon.

## Stack
- HTML / CSS / JavaScript pur (zéro dépendance)
- PWA installable sur iOS, Android, PC, Mac
- Données : FFRS, World Skate, résultats réels 2025-2026

## Déploiement Vercel (automatique)

### 1. Créer le dépôt GitHub
```bash
git init
git add .
git commit -m "Initial commit — Speed Skating Manager"
git branch -M main
git remote add origin https://github.com/TON_PSEUDO/speed-skating-manager.git
git push -u origin main
```

### 2. Déployer sur Vercel
1. Va sur **vercel.com** → "Add New Project"
2. Connecte ton compte GitHub
3. Sélectionne le dépôt `speed-skating-manager`
4. Framework Preset : **Other**
5. Clique **Deploy**
6. Ton URL est générée : `speed-skating-manager.vercel.app`

### 3. Personnaliser l'URL
Dans Vercel → Settings → Domains → ajoute `speed-skating-manager.vercel.app`
ou un domaine personnalisé.

### 4. Déploiement automatique
Chaque `git push` sur `main` redéploie automatiquement l'app.
```bash
# Mettre à jour l'app
git add index.html
git commit -m "Mise à jour calendrier / nouveaux athlètes"
git push
# → Vercel redéploie en ~30 secondes
```

## Contenu
- 55+ patineurs réels (Europa Cup, WSMT, CFRV, Championnats France)
- 25+ épreuves internationales et françaises
- Mode Manager + Mode The Race
- Classement, Ligues privées
- PWA : installable sur tous appareils
